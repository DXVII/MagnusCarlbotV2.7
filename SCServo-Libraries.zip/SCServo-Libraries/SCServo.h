/*
 * SCServo.h
 * 飞特串行舵机接口
 * 日期: 2017.12.8
 * 作者: 谭雄乐
 */

#ifndef _SCSERVO_H
#define _SCSERVO_H

#include "SMSBL.h" 
#include "SCSCL.h"
#include "SMSCL.h"

#endif